#ifdef __cplusplus
extern "C" {
#endif

#include <numpy/npy_math.h>

#ifdef __cplusplus
}
#endif
