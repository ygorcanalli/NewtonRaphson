
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.12.0b1'
version = '0.12.0b1'
full_version = '0.12.0b1'
git_revision = 'f46008831247e3e1e8e2902dfbcf6c29e9545bf7'
release = True

if not release:
    version = full_version
